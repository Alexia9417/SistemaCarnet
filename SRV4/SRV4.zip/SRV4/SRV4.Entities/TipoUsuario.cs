﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SRV4.Entities
{
    [Table("tipos_usuario")]
    public class TipoUsuario
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = null!;
    }
}
