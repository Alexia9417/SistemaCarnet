﻿using Microsoft.EntityFrameworkCore;
using SRV4.Data;
using SRV4.Entities;

namespace SRV4.Logic
{
    public class TipoUsuarioservice : ITipoUsuarioservice
    {
        private readonly TipoUContext _context;

        public TipoUsuarioservice(TipoUContext context) => _context = context;

        public async Task<IEnumerable<TipoUsuario>> ObtenerTodas() =>
            await _context.TiposUsuario.ToListAsync();

        public async Task<TipoUsuario?> ObtenerPorId(int id) =>
            await _context.TiposUsuario.FindAsync(id);

        public async Task Crear(TipoUsuario tipoUsuario)
        {
            _context.TiposUsuario.Add(tipoUsuario);
            await _context.SaveChangesAsync();
        }

        public async Task Modificar(TipoUsuario tipoUsuario)
        {
            _context.TiposUsuario.Update(tipoUsuario);
            await _context.SaveChangesAsync();
        }

        public async Task Eliminar(int id)
        {
            var tipoUsuario = await _context.TiposUsuario.FindAsync(id);
            if (tipoUsuario != null)
            {
                _context.TiposUsuario.Remove(tipoUsuario);
                await _context.SaveChangesAsync();
            }
        }
        public async Task<bool> ExisteNombreAsync(string nombre)
        {
            return await _context.TiposUsuario
                .AnyAsync(c => c.Nombre.Trim().ToLower() == nombre.Trim().ToLower());
        }
    }
}
