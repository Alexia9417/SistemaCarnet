﻿using SRV4.Entities;

namespace SRV4.Logic
{
    public interface ITipoUsuarioservice
    {
        Task<IEnumerable<TipoUsuario>> ObtenerTodas();
        Task<TipoUsuario?> ObtenerPorId(int id);
        Task Crear(TipoUsuario tipoUsuario);
        Task Modificar(TipoUsuario tipoUsuario);
        Task Eliminar(int id);
        Task<bool> ExisteNombreAsync(string nombre);
    }
}
