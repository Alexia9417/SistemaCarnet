﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SRV4.Entities;
using SRV4.Logic;

namespace SRV4.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TiposUsuariosController : ControllerBase
    {
        private readonly ITipoUsuarioservice _service;

        public TiposUsuariosController(ITipoUsuarioservice service) => _service = service;

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var tipoUsuarios = await _service.ObtenerTodas();
                return Ok(new { isSuccess = true, data = tipoUsuarios });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new
                {
                    isSuccess = false,
                    message = "Error al obtener los tipos de usuario.",
                    error = ex.Message
                });
            }
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            var tipoUsuario = await _service.ObtenerPorId(id);

            if (tipoUsuario == null)
            {
                return NotFound(new
                {
                    isSuccess = false,
                    message = $"No se encontró un tipo de usuario con ID {id}."
                });
            }

            return Ok(new
            {
                isSuccess = true,
                data = tipoUsuario
            });
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] TipoUsuario tipoUsuario)
        {
            if (string.IsNullOrWhiteSpace(tipoUsuario.Nombre))
            {
                return BadRequest(new
                {
                    isSuccess = false,
                    message = "El nombre del tipo de usuario es obligatorio."
                });
            }

            if (await _service.ExisteNombreAsync(tipoUsuario.Nombre))
            {
                return Conflict(new
                {
                    isSuccess = false,
                    message = "Ya existe un tipo de usuario registrado con ese nombre."
                });
            }

            try
            {
                await _service.Crear(tipoUsuario);

                return CreatedAtAction(nameof(Get), new { id = tipoUsuario.Id }, new
                {
                    isSuccess = true,
                    message = "Tipo de usuario registrado correctamente.",
                    data = tipoUsuario
                });
            }
            catch (Exception ex)
            {
                var error = ex.InnerException?.Message ?? ex.Message;
                return StatusCode(500, new
                {
                    isSuccess = false,
                    message = "Error al registrar el tipo de usuario.",
                    error
                });
            }
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Put(int id, [FromBody] TipoUsuario tipoUsuario)
        {
            if (id != tipoUsuario.Id)
            {
                return BadRequest(new
                {
                    isSuccess = false,
                    message = "El ID de la URL no coincide con el ID del tipo de usuario."
                });
            }

            var tUsuarioExistente = await _service.ObtenerPorId(id);
            if (tUsuarioExistente == null)
            {
                return NotFound(new
                {
                    isSuccess = false,
                    message = $"No se encontró un tipo de usuario con ID {id}."
                });
            }
            try
            {
                tUsuarioExistente.Nombre = !string.IsNullOrWhiteSpace(tipoUsuario.Nombre)
                    ? tipoUsuario.Nombre.Trim()
                    : tUsuarioExistente.Nombre;


                await _service.Modificar(tUsuarioExistente);

                return Ok(new
                {
                    isSuccess = true,
                    message = "Tipo de usuario actualizado correctamente.",
                    data = tUsuarioExistente
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    isSuccess = false,
                    message = "Error interno al modificar el tipo de usuario.",
                    error = ex.InnerException?.Message ?? ex.Message
                });
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var tipoUsuario = await _service.ObtenerPorId(id);

            if (tipoUsuario == null)
            {
                return NotFound(new
                {
                    isSuccess = false,
                    message = $"No se encontró un tipo de usuario con ID {id}."
                });
            }

            try
            {
                await _service.Eliminar(id);

                return Ok(new
                {
                    isSuccess = true,
                    message = "Tipo de usuario eliminado correctamente.",
                    data = tipoUsuario
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    isSuccess = false,
                    message = "Error interno al eliminar el tipo de usuario.",
                    error = ex.InnerException?.Message ?? ex.Message
                });
            }
        }


    }
}
