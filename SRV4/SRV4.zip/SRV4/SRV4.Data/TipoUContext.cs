﻿using Microsoft.EntityFrameworkCore;
using SRV4.Entities;


namespace SRV4.Data
{
    public class TipoUContext : DbContext
    {
        public TipoUContext(DbContextOptions<TipoUContext> options) : base(options) { }
        
        public DbSet<TipoUsuario> TiposUsuario => Set<TipoUsuario>();
 
    }
}
