﻿

namespace SRV3.Entities
{
    public class Carrera
    {
        public int Id { get; set; }

        public string Nombre { get; set; } = null!;

        public string Director { get; set; } = null!;

        public string Email { get; set; } = null!;

        public int Telefono { get; set; }


    }
}
