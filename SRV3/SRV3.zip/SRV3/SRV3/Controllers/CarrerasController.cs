﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SRV3.Entities;
using SRV3.Logic;

namespace SRV3.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CarrerasController : ControllerBase
    {
        private readonly ICarreraService _service;

        private readonly Validaciones _validador;

        public CarrerasController(ICarreraService service, Validaciones validador)
        {
            _service = service;
            _validador = validador;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var carreras = await _service.ObtenerTodas();
                return Ok(new { isSuccess = true, data = carreras });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new
                {
                    isSuccess = false,
                    message = "Error al obtener las carreras.",
                    error = ex.Message
                });
            }
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            var carrera = await _service.ObtenerPorId(id);

            if (carrera == null)
            {
                return NotFound(new
                {
                    isSuccess = false,
                    message = $"No se encontró una carrera con ID {id}."
                });
            }

            return Ok(new
            {
                isSuccess = true,
                data = carrera
            });
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Carrera carrera)
        {
            // Validar campos obligatorios
            if (string.IsNullOrWhiteSpace(carrera.Nombre) ||
                string.IsNullOrWhiteSpace(carrera.Director) ||
                string.IsNullOrWhiteSpace(carrera.Email))
            {
                return BadRequest(new
                {
                    isSuccess = false,
                    message = "Nombre, director y email son obligatorios."
                });
            }

            // Validar formato de email
            if (!Validaciones.EmailValido(carrera.Email))
            {
                return BadRequest(new
                {
                    isSuccess = false,
                    message = "El formato del email no es válido."
                });
            }

            // Validar formato de teléfono
            if (!Validaciones.TelefonoValido(carrera.Telefono))
            {
                return BadRequest(new
                {
                    isSuccess = false,
                    message = "El número de teléfono debe contener solo dígitos y tener al menos 8 caracteres."
                });
            }

            // Validar que no exista ya una carrera con el mismo nombre
            if (await _service.ExisteNombreAsync(carrera.Nombre))
            {
                return Conflict(new
                {
                    isSuccess = false,
                    message = "Ya existe una carrera registrada con ese nombre."
                });
            }

            try
            {
                await _service.Crear(carrera);

                return CreatedAtAction(nameof(Get), new { id = carrera.Id }, new
                {
                    isSuccess = true,
                    message = "Carrera registrada correctamente.",
                    data = carrera
                });
            }
            catch (Exception ex)
            {
                var error = ex.InnerException?.Message ?? ex.Message;
                return StatusCode(500, new
                {
                    isSuccess = false,
                    message = "Error al registrar carrera.",
                    error
                });
            }
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Put(int id, [FromBody] Carrera carrera)
        {
            if (id != carrera.Id)
            {
                return BadRequest(new
                {
                    isSuccess = false,
                    message = "El ID de la URL no coincide con el ID de la carrera."
                });
            }

            var carreraExistente = await _service.ObtenerPorId(id);
            if (carreraExistente == null)
            {
                return NotFound(new
                {
                    isSuccess = false,
                    message = $"No se encontró una carrera con ID {id}."
                });
            }

            try
            {
                carreraExistente.Nombre = !string.IsNullOrWhiteSpace(carrera.Nombre)
                    ? carrera.Nombre.Trim()
                    : carreraExistente.Nombre;

                carreraExistente.Director = !string.IsNullOrWhiteSpace(carrera.Director)
                    ? carrera.Director.Trim()
                    : carreraExistente.Director;

                carreraExistente.Email = !string.IsNullOrWhiteSpace(carrera.Email)
                    ? carrera.Email.Trim()
                    : carreraExistente.Email;

                carreraExistente.Telefono = carrera.Telefono != 0
                    ? carrera.Telefono
                    : carreraExistente.Telefono;

                await _service.Modificar(carreraExistente);

                return Ok(new
                {
                    isSuccess = true,
                    message = "Carrera actualizada correctamente.",
                    data = carreraExistente
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    isSuccess = false,
                    message = "Error interno al modificar la carrera.",
                    error = ex.InnerException?.Message ?? ex.Message
                });
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var carrera = await _service.ObtenerPorId(id);

            if (carrera == null)
            {
                return NotFound(new
                {
                    isSuccess = false,
                    message = $"No se encontró una carrera con ID {id}."
                });
            }

            try
            {
                await _service.Eliminar(id);

                return Ok(new
                {
                    isSuccess = true,
                    message = "Carrera eliminada correctamente.",
                    data = carrera
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    isSuccess = false,
                    message = "Error interno al eliminar la carrera.",
                    error = ex.InnerException?.Message ?? ex.Message
                });
            }
        }

    }
}
