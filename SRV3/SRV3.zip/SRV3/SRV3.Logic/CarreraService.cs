﻿using Microsoft.EntityFrameworkCore;
using SRV3.Data;
using SRV3.Entities;

namespace SRV3.Logic
{
    public class CarreraService : ICarreraService
    {
        private readonly CarreraContext _context;

        public CarreraService(CarreraContext context) => _context = context;

        public async Task<IEnumerable<Carrera>> ObtenerTodas() =>
            await _context.Carreras.ToListAsync();

        public async Task<Carrera?> ObtenerPorId(int id) =>
            await _context.Carreras.FindAsync(id);

        public async Task Crear(Carrera carrera)
        {
            _context.Carreras.Add(carrera);
            await _context.SaveChangesAsync();
        }

        public async Task Modificar(Carrera carrera)
        {
            _context.Carreras.Update(carrera);
            await _context.SaveChangesAsync();
        }

        public async Task Eliminar(int id)
        {
            var carrera = await _context.Carreras.FindAsync(id);
            if (carrera != null)
            {
                _context.Carreras.Remove(carrera);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ExisteNombreAsync(string nombre)
        {
            return await _context.Carreras
                .AnyAsync(c => c.Nombre.Trim().ToLower() == nombre.Trim().ToLower());
        }

    }
}
