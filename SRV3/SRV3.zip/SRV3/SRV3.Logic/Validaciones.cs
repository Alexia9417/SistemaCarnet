﻿using Microsoft.EntityFrameworkCore;
using SRV3.Data;
using System.Text.RegularExpressions;

namespace SRV3.Logic
{
    public class Validaciones
    {
        private readonly CarreraContext _context;

        public Validaciones(CarreraContext context)
        {
            _context = context;
        }

        public static bool EmailValido(string email)
        {
            var regex = new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");
            return regex.IsMatch(email);
        }

        public static bool TelefonoValido(int telefono)
        {
            return telefono > 0 && telefono.ToString().Length >= 8;
        }

    }
}
