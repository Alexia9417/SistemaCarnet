﻿using SRV3.Entities;

namespace SRV3.Logic
{
    public interface ICarreraService
    {
        Task<IEnumerable<Carrera>> ObtenerTodas();
        Task<Carrera?> ObtenerPorId(int id);
        Task Crear(Carrera carrera);
        Task Modificar(Carrera carrera);
        Task Eliminar(int id);
        Task<bool> ExisteNombreAsync(string nombre);
    }
}
