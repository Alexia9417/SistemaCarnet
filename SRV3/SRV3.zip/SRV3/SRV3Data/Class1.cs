﻿namespace SRV3Data
{
    public class Class1
    {

    }
}
