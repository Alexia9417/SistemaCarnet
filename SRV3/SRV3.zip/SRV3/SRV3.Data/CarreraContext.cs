﻿using Microsoft.EntityFrameworkCore;
using SRV3.Entities;

namespace SRV3.Data
{
    public class CarreraContext : DbContext
    {
        public CarreraContext(DbContextOptions<CarreraContext> options) : base(options) { }

        public DbSet<Carrera> Carreras => Set<Carrera>();
    }
}
