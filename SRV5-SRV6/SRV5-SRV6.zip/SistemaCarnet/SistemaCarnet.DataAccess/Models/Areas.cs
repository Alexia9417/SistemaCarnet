﻿using System;
using System.Collections.Generic;

namespace SistemaCarnet.DataAccess.Models;

public partial class Areas
{
    public int Id { get; set; }

    public string Nombre { get; set; } = null!;

    public virtual ICollection<Usuarios> UsuarioEmail { get; set; } = new List<Usuarios>();
}
