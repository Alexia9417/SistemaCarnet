﻿using System;
using System.Collections.Generic;

namespace SistemaCarnet.DataAccess.Models;

public partial class Tokens
{
    public int Id { get; set; }

    public string UsuarioEmail { get; set; } = null!;

    public string Token { get; set; } = null!;

    public string Tipo { get; set; } = null!;

    public DateTime CreadoEn { get; set; }

    public DateTime? Expiacion { get; set; }

    public bool Archivo { get; set; }

    public virtual Usuarios UsuarioEmailNavigation { get; set; } = null!;
}
