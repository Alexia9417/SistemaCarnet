﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace SistemaCarnet.DataAccess.Models;

public partial class SistemaCarnetContext : DbContext
{
    public SistemaCarnetContext()
    {
    }

    public SistemaCarnetContext(DbContextOptions<SistemaCarnetContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Areas> Areas { get; set; }

    public virtual DbSet<Carreras> Carreras { get; set; }

    public virtual DbSet<Estado> Estado { get; set; }

    public virtual DbSet<TiposIdentificacion> TiposIdentificacion { get; set; }

    public virtual DbSet<TiposUsuario> TiposUsuario { get; set; }

    public virtual DbSet<Tokens> Tokens { get; set; }

    public virtual DbSet<UsuarioFoto> UsuarioFoto { get; set; }

    public virtual DbSet<UsuarioQr> UsuarioQr { get; set; }

    public virtual DbSet<UsuarioTelefonos> UsuarioTelefonos { get; set; }

    public virtual DbSet<Usuarios> Usuarios { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Name=DefaultConnection");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Areas>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__areas__3213E83FA0BF4821");

            entity.ToTable("areas");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Nombre)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("nombre");
        });

        modelBuilder.Entity<Carreras>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__carreras__3213E83F3D76A8CB");

            entity.ToTable("carreras");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Director)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("director");
            entity.Property(e => e.Email)
                .HasMaxLength(70)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.Nombre)
                .HasMaxLength(35)
                .IsUnicode(false)
                .HasColumnName("nombre");
            entity.Property(e => e.Telefono)
                .HasMaxLength(8)
                .IsUnicode(false)
                .HasColumnName("telefono");
        });

        modelBuilder.Entity<Estado>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__estado__3213E83F999A86FF");

            entity.ToTable("estado");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Nombre)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("nombre");
        });

        modelBuilder.Entity<TiposIdentificacion>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__tipos_id__3213E83FE2912A49");

            entity.ToTable("tipos_identificacion");

            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("id");

            entity.Property(e => e.Nombre)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("nombre");
        });


        modelBuilder.Entity<TiposUsuario>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__tipos_us__3213E83F6EAA9BFD");

            entity.ToTable("tipos_usuario");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Nombre)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("nombre");
        });

        modelBuilder.Entity<Tokens>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__tokens__3213E83FCCAE74F6");

            entity.ToTable("tokens");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Archivo).HasColumnName("archivo");
            entity.Property(e => e.CreadoEn)
                .HasColumnType("datetime")
                .HasColumnName("creado_en");
            entity.Property(e => e.Expiacion)
                .HasColumnType("datetime")
                .HasColumnName("expiacion");
            entity.Property(e => e.Tipo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("tipo");
            entity.Property(e => e.Token)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("token");
            entity.Property(e => e.UsuarioEmail)
                .HasMaxLength(70)
                .IsUnicode(false)
                .HasColumnName("usuario_email");

            entity.HasOne(d => d.UsuarioEmailNavigation).WithMany(p => p.Tokens)
                .HasForeignKey(d => d.UsuarioEmail)
                .HasConstraintName("FK__tokens__usuario___44FF419A");
        });

        modelBuilder.Entity<UsuarioFoto>(entity =>
        {
            entity.HasKey(e => e.UsuarioEmail).HasName("PK__usuario___1C1E9105519863FE");

            entity.ToTable("usuario_foto");

            entity.Property(e => e.UsuarioEmail)
                .HasMaxLength(70)
                .IsUnicode(false)
                .HasColumnName("usuario_email");
            entity.Property(e => e.Imagen).HasColumnName("imagen");

            entity.HasOne(d => d.UsuarioEmailNavigation).WithOne(p => p.UsuarioFoto)
                .HasForeignKey<UsuarioFoto>(d => d.UsuarioEmail)
                .HasConstraintName("FK__usuario_f__usuar__4222D4EF");
        });

        modelBuilder.Entity<UsuarioQr>(entity =>
        {
            entity.HasKey(e => e.UsuarioEmail).HasName("PK__usuario___1C1E9105CC5223F9");

            entity.ToTable("usuario_qr");

            entity.Property(e => e.UsuarioEmail)
                .HasMaxLength(70)
                .IsUnicode(false)
                .HasColumnName("usuario_email");
            entity.Property(e => e.CodigoQrBase64).HasColumnName("codigo_qr_base64");
            entity.Property(e => e.ContenidoJson).HasColumnName("contenido_json");
            entity.Property(e => e.FechaGenerado)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("fecha_generado");
            entity.Property(e => e.FechaVencimiento).HasColumnName("fecha_vencimiento");

            entity.HasOne(d => d.UsuarioEmailNavigation).WithOne(p => p.UsuarioQr)
                .HasForeignKey<UsuarioQr>(d => d.UsuarioEmail)
                .HasConstraintName("FK__usuario_q__usuar__571DF1D5");
        });

        modelBuilder.Entity<UsuarioTelefonos>(entity =>
        {
            entity.HasKey(e => e.Numero).HasName("PK__usuario___FC77F210BDF100DE");

            entity.ToTable("usuario_telefonos");

            entity.Property(e => e.Numero)
                .ValueGeneratedNever()
                .HasColumnName("numero");
            entity.Property(e => e.UsuarioEmail)
                .HasMaxLength(70)
                .IsUnicode(false)
                .HasColumnName("usuario_email");

            entity.HasOne(d => d.UsuarioEmailNavigation).WithMany(p => p.UsuarioTelefonos)
                .HasForeignKey(d => d.UsuarioEmail)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__usuario_t__usuar__534D60F1");
        });

        modelBuilder.Entity<Usuarios>(entity =>
        {
            entity.HasKey(e => e.Email).HasName("PK__usuarios__AB6E6165D4E8E65D");

            entity.ToTable("usuarios");

            entity.Property(e => e.Email)
                .HasMaxLength(70)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.Apellidos)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("apellidos");
            entity.Property(e => e.Contrasena)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("contrasena");
            entity.Property(e => e.Estado).HasColumnName("estado");
            entity.Property(e => e.Identificacion)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("identificacion");
            entity.Property(e => e.NombreCompleto)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nombre_completo");
            entity.Property(e => e.TipoIdentificacionId).HasColumnName("tipo_identificacion_id");
            entity.Property(e => e.TipoUsuarioId).HasColumnName("tipo_usuario_id");

            entity.HasOne(d => d.EstadoNavigation).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.Estado)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__usuarios__estado__3F466844");

            entity.HasOne(d => d.TipoIdentificacion).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.TipoIdentificacionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__usuarios__tipo_i__3D5E1FD2");

            entity.HasOne(d => d.TipoUsuario).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.TipoUsuarioId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__usuarios__tipo_u__3E52440B");

            entity.HasMany(d => d.Area).WithMany(p => p.UsuarioEmail)
                .UsingEntity<Dictionary<string, object>>(
                    "UsuarioAreas",
                    r => r.HasOne<Areas>().WithMany()
                        .HasForeignKey("AreaId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__usuario_a__area___5070F446"),
                    l => l.HasOne<Usuarios>().WithMany()
                        .HasForeignKey("UsuarioEmail")
                        .HasConstraintName("FK__usuario_a__usuar__4F7CD00D"),
                    j =>
                    {
                        j.HasKey("UsuarioEmail", "AreaId").HasName("PK__usuario___B59B47D36458C944");
                        j.ToTable("usuario_areas");
                        j.IndexerProperty<string>("UsuarioEmail")
                            .HasMaxLength(70)
                            .IsUnicode(false)
                            .HasColumnName("usuario_email");
                        j.IndexerProperty<int>("AreaId").HasColumnName("area_id");
                    });

            entity.HasMany(d => d.Carrera).WithMany(p => p.UsuarioEmail)
                .UsingEntity<Dictionary<string, object>>(
                    "UsuarioCarreras",
                    r => r.HasOne<Carreras>().WithMany()
                        .HasForeignKey("CarreraId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__usuario_c__carre__4AB81AF0"),
                    l => l.HasOne<Usuarios>().WithMany()
                        .HasForeignKey("UsuarioEmail")
                        .HasConstraintName("FK__usuario_c__usuar__49C3F6B7"),
                    j =>
                    {
                        j.HasKey("UsuarioEmail", "CarreraId").HasName("PK__usuario___0DEF7D752BB335AD");
                        j.ToTable("usuario_carreras");
                        j.IndexerProperty<string>("UsuarioEmail")
                            .HasMaxLength(70)
                            .IsUnicode(false)
                            .HasColumnName("usuario_email");
                        j.IndexerProperty<int>("CarreraId").HasColumnName("carrera_id");
                    });
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
