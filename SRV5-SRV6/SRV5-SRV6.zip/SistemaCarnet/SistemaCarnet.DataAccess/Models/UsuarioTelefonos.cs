﻿using System;
using System.Collections.Generic;

namespace SistemaCarnet.DataAccess.Models;

public partial class UsuarioTelefonos
{
    public int Numero { get; set; }

    public string? UsuarioEmail { get; set; }

    public virtual Usuarios? UsuarioEmailNavigation { get; set; }
}
