﻿using System;
using System.Collections.Generic;

namespace SistemaCarnet.DataAccess.Models;

public partial class Usuarios
{
    public string Email { get; set; } = null!;

    public int TipoIdentificacionId { get; set; }

    public string Identificacion { get; set; } = null!;

    public string NombreCompleto { get; set; } = null!;

    public string Apellidos { get; set; } = null!;

    public string Contrasena { get; set; } = null!;

    public int TipoUsuarioId { get; set; }

    public int Estado { get; set; }

    public virtual Estado EstadoNavigation { get; set; } = null!;

    public virtual TiposIdentificacion TipoIdentificacion { get; set; } = null!;

    public virtual TiposUsuario TipoUsuario { get; set; } = null!;

    public virtual ICollection<Tokens> Tokens { get; set; } = new List<Tokens>();

    public virtual UsuarioFoto? UsuarioFoto { get; set; }

    public virtual UsuarioQr? UsuarioQr { get; set; }

    public virtual ICollection<UsuarioTelefonos> UsuarioTelefonos { get; set; } = new List<UsuarioTelefonos>();

    public virtual ICollection<Areas> Area { get; set; } = new List<Areas>();

    public virtual ICollection<Carreras> Carrera { get; set; } = new List<Carreras>();
}
