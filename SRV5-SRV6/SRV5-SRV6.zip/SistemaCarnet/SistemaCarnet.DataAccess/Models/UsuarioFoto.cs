﻿using System;
using System.Collections.Generic;

namespace SistemaCarnet.DataAccess.Models;

public partial class UsuarioFoto
{
    public string UsuarioEmail { get; set; } = null!;

    public string Imagen { get; set; } = null!;

    public virtual Usuarios UsuarioEmailNavigation { get; set; } = null!;
}
