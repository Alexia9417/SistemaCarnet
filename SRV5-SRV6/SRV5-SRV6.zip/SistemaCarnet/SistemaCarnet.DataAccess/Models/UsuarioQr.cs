﻿using System;
using System.Collections.Generic;

namespace SistemaCarnet.DataAccess.Models;

public partial class UsuarioQr
{
    public string UsuarioEmail { get; set; } = null!;

    public string ContenidoJson { get; set; } = null!;

    public string CodigoQrBase64 { get; set; } = null!;

    public DateOnly FechaVencimiento { get; set; }

    public DateTime FechaGenerado { get; set; }

    public virtual Usuarios UsuarioEmailNavigation { get; set; } = null!;
}
