﻿namespace ServicioPhotoTipoIden.Configuration
{
    public class TokenValidationOptions
    {
        public required string LoginApiUrl { get; set; }
    }
}
