﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;
using SistemaCarnet.DataAccess.Models;
using ServicioPhotoTipoIden.Configuration;
using ServicioPhotoTipoIden.Filter;
using PhotoService;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddControllers();

//Config del token
builder.Services.Configure<TokenValidationOptions>(
    builder.Configuration.GetSection("TokenValidation"));
builder.Services.AddHttpClient();
builder.Services.AddScoped<Validate>();

//Inyeccion de dependencias (Antes del Build)
builder.Services.AddDbContext<SistemaCarnetContext>(options =>
{
    options.UseSqlServer("name=ConnectionStrings:DefaultConnection");
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapUsuarioFotoEndpoints();

app.MapTiposIdentificacionEndpoints();

app.Run();
