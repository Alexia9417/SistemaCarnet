﻿//ServicioPhotoTipoIden/TiposIdentificacionEndpoints.cs
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.OpenApi;
using SistemaCarnet.DataAccess.Models;
using Microsoft.AspNetCore.Mvc;
using ServicioPhotoTipoIden.Filter;
namespace PhotoService;

public static class TiposIdentificacionEndpoints
{
    //requiere el validate Control [ServiceFilter(typeof(Validate))] 


    public static void MapTiposIdentificacionEndpoints (this IEndpointRouteBuilder routes)
    {
        //Endpoint base: /tiposIdentificacion
        var group = routes.MapGroup("/tiposidentificacion")
                  .AddEndpointFilter<Validate>()
                  .WithTags(nameof(TiposIdentificacion));


        /*────────────────────────────  GET /tiposidentificacion  ────────────────────────────*/
        group.MapGet("/", async (SistemaCarnetContext db) =>
        {
            return await db.TiposIdentificacion.ToListAsync();
        })
        .WithName("ObtenerTodosTiposIdentificacions")
        .WithOpenApi();

        /*─────────────────────────  GET /tiposidentificacion/{id}  ─────────────────────────*/
        group.MapGet("/{id:int}", async Task<Results<Ok<TiposIdentificacion>, NotFound>> (int id, SistemaCarnetContext db) =>
        {
            var tipo = await db.TiposIdentificacion
                .AsNoTracking()
                .FirstOrDefaultAsync(t => t.Id == id);

            return tipo is null ? TypedResults.NotFound() : TypedResults.Ok(tipo);
        })
        .Produces<TiposIdentificacion>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound)
        .WithName("ObtenerTipoIdentificacionPorId");

        /*───────────────────────────  PUT /tiposidentificacion/{id}  ─────────────────────────*/
        group.MapPut("/{id:int}", async Task<Results<NoContent, NotFound, BadRequest<string>>> (int id, TiposIdentificacion dto, SistemaCarnetContext db) =>
        {
            if (string.IsNullOrWhiteSpace(dto.Nombre))
                    return TypedResults.BadRequest("El nombre del tipo de identificación es obligatorio.");

                var existeOtro = await db.TiposIdentificacion
                                         .AnyAsync(t => t.Id != id &&
                                                        t.Nombre.ToLower() == dto.Nombre.ToLower());
                if (existeOtro)
                    return TypedResults.BadRequest("Ya existe otro tipo de identificación con ese nombre.");

                var filas = await db.TiposIdentificacion
                                    .Where(t => t.Id == id)
                                    .ExecuteUpdateAsync(setters =>
                                        setters.SetProperty(t => t.Nombre, dto.Nombre));

                return filas == 0 ? TypedResults.NotFound()
                                  : TypedResults.NoContent();
        })
        .Produces(StatusCodes.Status204NoContent)
        .Produces<string>(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status404NotFound)
        .WithName("ActualizarTipoIdentificacion");

        /*────────────────────────────  POST /tiposidentificacion  ───────────────────────────*/
        group.MapPost("/", async Task<Results<Created<TiposIdentificacion>, BadRequest<string>>> (TiposIdentificacion dto, SistemaCarnetContext db) =>
        {
            /* Validaciones */
            if (string.IsNullOrWhiteSpace(dto.Nombre))
                return TypedResults.BadRequest("El nombre del tipo de identificación es obligatorio.");

            //Por si el usuario ingresa el campo de id y pone algo diferente a 0
            if (dto.Id != 0)
                return TypedResults.BadRequest("El campo 'Id' no debe enviarse o debe ser 0, ya que se asigna automáticamente.");

            /* Evitar duplicados por nombre */
            bool nombreDuplicado = await db.TiposIdentificacion
                                           .AnyAsync(t => t.Nombre.ToLower() == dto.Nombre.ToLower());
            if (nombreDuplicado)
                return TypedResults.BadRequest("Ya existe un tipo de identificación con ese nombre.");

            dto.Id = 0; //forzamos que Id sea cero antes de insertar

            /* Crear registro */
            try
            {
                db.TiposIdentificacion.Add(dto);
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return TypedResults.BadRequest($"Error al guardar: {ex.InnerException?.Message ?? ex.Message}");
            }

            return TypedResults.Created($"/tiposidentificacion/{dto.Id}", dto);
        })
        .Produces<TiposIdentificacion>(StatusCodes.Status201Created)
        .Produces<string>(StatusCodes.Status400BadRequest)
        .WithName("CrearTipoIdentificacion");

        /*────────────────────────  DELETE /tiposidentificacion/{id}  ────────────────────────*/
        group.MapDelete("/{id:int}", async Task<Results<Ok<TiposIdentificacion>, NotFound>> (int id, SistemaCarnetContext db) =>
        {
            var tipo = await db.TiposIdentificacion.FindAsync(id);

            if (tipo is null)
                return TypedResults.NotFound();

            db.TiposIdentificacion.Remove(tipo);
            await db.SaveChangesAsync();

            return TypedResults.Ok(tipo);
        })
        .Produces<TiposIdentificacion>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound)
        .WithName("EliminarTipoIdentificacion");

    }
}
