﻿// ServicioPhotoTipoIden/UsuarioFotoEndpoints.cs
using Microsoft.AspNetCore.Authorization;
using System.Net.Mime;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.OpenApi;
using SistemaCarnet.DataAccess.Models;
using Microsoft.AspNetCore.Mvc;
using ServicioPhotoTipoIden.Filter;
namespace PhotoService;

public static class UsuarioFotoEndpoints
{
    //requiere el validate Control [ServiceFilter(typeof(Validate))] 

    // Tamaño máximo permitido de la imagen: 1 MB
    private const int MaxImageBytes = 1 * 1024 * 1024;

    public static void MapUsuarioFotoEndpoints(this IEndpointRouteBuilder routes)
    {
        var group = routes.MapGroup("/usuario/fotografia")
                  .AddEndpointFilter<Validate>() //Aqui se verifica con el validate
                  .WithTags(nameof(UsuarioFoto));

        group.MapPost("/", CrearOActualizarFoto)
            .Accepts<FotoRequest>(MediaTypeNames.Application.Json)
            .Produces<UsuarioFoto>(StatusCodes.Status201Created)
            .Produces<UsuarioFoto>(StatusCodes.Status200OK)
            .Produces<string>(StatusCodes.Status400BadRequest)
            .WithName("ActualizarUsuarioFoto")
            .WithOpenApi();

        group.MapGet("/{usuarioEmail}", ObtenerFoto)
             .Produces<UsuarioFoto>(StatusCodes.Status200OK)
             .Produces(StatusCodes.Status404NotFound)
             .WithName("ObtenerUsuarioFotoPorCorreo")
             .WithOpenApi();

        group.MapDelete("/{usuarioEmail}", EliminarFoto)
             .Produces(StatusCodes.Status200OK)
             .Produces(StatusCodes.Status404NotFound)
             .WithName("EliminarUsuarioFoto")
             .WithOpenApi();
    }

    private static async Task<Results<Created<UsuarioFoto>, Ok<UsuarioFoto>, BadRequest<string>>> CrearOActualizarFoto(
        FotoRequest dto,
        SistemaCarnetContext db)
    {
        if (string.IsNullOrWhiteSpace(dto.UsuarioEmail))
            return TypedResults.BadRequest("El correo del usuario es obligatorio.");

        if (string.IsNullOrWhiteSpace(dto.ImagenBase64))
            return TypedResults.BadRequest("La imagen en formato Base64 es obligatoria.");

        if (Convert.FromBase64String(dto.ImagenBase64).Length > MaxImageBytes)
            return TypedResults.BadRequest("La imagen supera el tamaño permitido (1 MB).");

        var existente = await db.UsuarioFoto.FindAsync(dto.UsuarioEmail);
        if (existente is null)
        {
            var nuevo = new UsuarioFoto
            {
                UsuarioEmail = dto.UsuarioEmail,
                Imagen = dto.ImagenBase64
            };
            db.UsuarioFoto.Add(nuevo);
            await db.SaveChangesAsync();
            return TypedResults.Created($"/usuario/fotografia/{dto.UsuarioEmail}", nuevo);
        }
        else
        {
            existente.Imagen = dto.ImagenBase64;
            await db.SaveChangesAsync();
            return TypedResults.Ok(existente);
        }
    }

    private static async Task<Results<Ok<UsuarioFoto>, NotFound>> ObtenerFoto(string usuarioEmail, SistemaCarnetContext db)
    {
        var foto = await db.UsuarioFoto.AsNoTracking()
                                       .FirstOrDefaultAsync(f => f.UsuarioEmail == usuarioEmail);

        return foto is null ? TypedResults.NotFound()
                            : TypedResults.Ok(foto);
    }

    private static async Task<Results<Ok<UsuarioFoto>, NotFound>> EliminarFoto(string usuarioEmail, SistemaCarnetContext db)
    {
        var foto = await db.UsuarioFoto
            .FirstOrDefaultAsync(f => f.UsuarioEmail == usuarioEmail);

        if (foto is null)
            return TypedResults.NotFound();

        db.UsuarioFoto.Remove(foto);
        await db.SaveChangesAsync();

        return TypedResults.Ok(foto);
    }

    /// <summary>
    /// DTO que acepta solo imagen en Base64.
    /// </summary>
    public sealed record FotoRequest(
        string UsuarioEmail,
        string ImagenBase64);
}