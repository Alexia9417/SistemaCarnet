﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using ServicioPhotoTipoIden.Configuration;
using System.Text;
using System.Text.Json;

namespace ServicioPhotoTipoIden.Filter
{
    public class Validate : IEndpointFilter
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly TokenValidationOptions _options;

        public Validate(IHttpClientFactory clientFactory, IOptions<TokenValidationOptions> options)
        {
            _clientFactory = clientFactory;
            _options = options.Value;
        }

        public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
        {
            var httpContext = context.HttpContext;

            try
            {
                var authHeader = httpContext.Request.Headers["Authorization"].ToString();

                if (string.IsNullOrWhiteSpace(authHeader) || !authHeader.StartsWith("Bearer "))
                {
                    return Results.Unauthorized();
                }

                var token = authHeader.Replace("Bearer ", "");
                var cliente = _clientFactory.CreateClient();

                var contenido = new StringContent(JsonSerializer.Serialize(token), Encoding.UTF8, "application/json");
                var response = await cliente.PostAsync(_options.LoginApiUrl, contenido);

                if (!response.IsSuccessStatusCode)
                {
                    return Results.Unauthorized();
                }

                return await next(context);
            }
            catch
            {
                return Results.Problem("Error interno en el servidor", statusCode: 500);
            }
        }
    }
}
